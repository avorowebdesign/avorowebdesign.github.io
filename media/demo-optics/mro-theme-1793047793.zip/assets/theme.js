(function(){
  const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
  const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;

  // header: solide na hero
  const hdr=$('#hdr');
  if(hdr&&hdr.classList.contains('hdr--over')){const h=$('#h3d');const on=()=>hdr.classList.toggle('is-solid',!h||scrollY>h.offsetHeight-innerHeight-10);addEventListener('scroll',on,{passive:true});on()}
  // mobiel menu
  const bg=$('#burger'),mn=$('#mnav');
  if(bg)bg.addEventListener('click',()=>{const o=bg.getAttribute('aria-expanded')!=='true';bg.setAttribute('aria-expanded',o);mn.classList.toggle('is-open',o)});

  // reveal
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
  $$('.sec__head,.pc,.tile,.exam__grid>*,.store__grid>*').forEach((el,i)=>{el.classList.add('rv');el.style.transitionDelay=(i%4)*.07+'s';io.observe(el)});

  // oogmeting: lens volgt muis, anders zwevend
  const vis=$('#examVis');
  if(vis){let tx=.5,ty=.38,x=.5,y=.38,user=0;
    const set=()=>{x+=(tx-x)*.12;y+=(ty-y)*.12;vis.style.setProperty('--x',(x*100)+'%');vis.style.setProperty('--y',(y*100)+'%');};
    const lr=()=>vis.style.setProperty('--lr',Math.round(vis.clientWidth*.2)+'px');lr();addEventListener('resize',lr);
    vis.addEventListener('pointermove',e=>{const r=vis.getBoundingClientRect();tx=(e.clientX-r.left)/r.width;ty=(e.clientY-r.top)/r.height;user=performance.now()});
    (function loop(t){if(performance.now()-user>2500&&!reduce){tx=.5+Math.sin(t/1600)*.22;ty=.42+Math.sin(t/1100)*.2}set();requestAnimationFrame(loop)})(0);
  }

  // openingstijden: vandaag + open/dicht
  const open=$('#openNow');
  if(open){const now=new Date(new Date().toLocaleString('en-US',{timeZone:'Europe/Amsterdam'})),d=now.getDay(),h=now.getHours()+now.getMinutes()/60;
    $$('#hoursList [data-d="'+d+'"]').forEach(e=>e.classList.add('is-today'));
    const T={2:[10,17.5],3:[10,17.5],4:[10,17.5],5:[10,17.5],6:[10,17]}[d];const isOpen=T&&h>=T[0]&&h<T[1];
    open.classList.toggle('is-open',!!isOpen);open.querySelector('span').textContent=isOpen?'Nu open':(T?'Nu gesloten':'Vandaag op afspraak');}

  // collectie filter
  $$('.filters .chip').forEach(c=>c.addEventListener('click',()=>{$$('.filters .chip').forEach(x=>x.classList.toggle('is-on',x===c));const f=c.dataset.f;$$('#colGrid .gi').forEach(g=>g.classList.toggle('is-hidden',f!=='*'&&!g.dataset.tags.split(' ').includes(f)))}));

  // product: variant kiezen + ajax toevoegen
  const vj=$('#variants');
  if(vj){const V=JSON.parse(vj.textContent),fmt=c=>'€'+(c/100).toLocaleString('nl-NL',{minimumFractionDigits:c%100?2:0});
    const upd=()=>{const sel=$$('.opts').map(fs=>{const i=fs.querySelector('input:checked');return i?i.value:null});const v=V.find(v=>v.options.every((o,i)=>o===sel[i]));if(!v)return;
      $('#variantId').value=v.id;$('#price').textContent=fmt(v.price);const b=$('#addBtn');b.disabled=!v.available;b.textContent=v.available?'In winkelmand':'Uitverkocht';
      const u=new URL(location);u.searchParams.set('variant',v.id);history.replaceState(null,'',u)};
    $$('.opts input').forEach(i=>i.addEventListener('change',upd));
    $('#addForm').addEventListener('submit',async e=>{e.preventDefault();const b=$('#addBtn');b.disabled=true;
      try{await fetch('/cart/add.js',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:[{id:+$('#variantId').value,quantity:1}]})});
        const c=await (await fetch('/cart.js')).json();const n=$('#cartCount');n.textContent=c.item_count;n.hidden=false;
        const t=$('#toast');t.innerHTML='Toegevoegd aan je winkelmand <a href="/cart">Bekijk</a>';t.classList.add('is-on');setTimeout(()=>t.classList.remove('is-on'),3500)}
      finally{b.disabled=false}});
  }
})();
