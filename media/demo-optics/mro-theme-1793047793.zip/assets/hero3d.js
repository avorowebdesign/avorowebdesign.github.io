import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
// Procedureel brilmodel voor three.js. Exporteert buildGlasses(THREE, opts) -> Group
// opts: { shape:'round'|'square'|'aviator'|'cateye'|'pilot', frame:'black'|'tortoise'|'gold'|'crystal'|'green'|'silver', lens:'clear'|'dark'|'green'|'gradient'|'brown' }
function buildGlasses(THREE, opts = {}) {
  const { shape = 'square', frame = 'black', lens = 'clear', temples = 'match' } = opts;
  const G = new THREE.Group();

  // ---------- materialen ----------
  const tort = () => {
    const c = document.createElement('canvas'); c.width = c.height = 512; const x = c.getContext('2d');
    x.fillStyle = '#6b3a14'; x.fillRect(0, 0, 512, 512); x.filter = 'blur(7px)';
    for (let i = 0; i < 140; i++) {
      const r = 14 + Math.random() * 60, px = Math.random() * 512, py = Math.random() * 512;
      const k = Math.random(); const col = k < .45 ? '#2a1307' : (k < .75 ? '#c27a2c' : (k < .9 ? '#e0a050' : '#4a220b'));
      x.globalAlpha = .55 + Math.random() * .4; x.fillStyle = col; x.beginPath(); x.ellipse(px, py, r, r * (.35 + Math.random() * .5), Math.random() * 3, 0, 7); x.fill();
    }
    x.filter = 'none'; x.globalAlpha = 1;
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(2.2, 2.2); return t;
  };
  const metal = (c, r = .18) => new THREE.MeshPhysicalMaterial({ color: c, metalness: 1, roughness: r, clearcoat: .3 });
  const FR = {
    black: new THREE.MeshPhysicalMaterial({ color: 0x0b0b0c, roughness: .12, metalness: 0, clearcoat: 1, clearcoatRoughness: .05 }),
    tortoise: new THREE.MeshPhysicalMaterial({ map: tort(), roughness: .1, clearcoat: 1, clearcoatRoughness: .04, transmission: .25, thickness: .4, ior: 1.5 }),
    crystal: new THREE.MeshPhysicalMaterial({ color: 0xe9e4da, roughness: .05, transmission: .85, thickness: .6, ior: 1.5, clearcoat: 1, transparent: true }),
    green: new THREE.MeshPhysicalMaterial({ color: 0x1f3a2c, roughness: .12, clearcoat: 1, clearcoatRoughness: .05 }),
    gold: metal(0xe3c07e, .16),
    silver: metal(0xd8d8da, .14),
    gunmetal: metal(0x5a5c62, .22),
  };
  const fm = FR[frame] || FR.black;
  const LN = {
    clear: new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0, transmission: 1, thickness: .02, ior: 1.5, transparent: true, opacity: .25, clearcoat: 1 }),
    dark: new THREE.MeshPhysicalMaterial({ color: 0x0e1113, roughness: .03, metalness: .2, transparent: true, opacity: .9, clearcoat: 1 }),
    green: new THREE.MeshPhysicalMaterial({ color: 0x1d3324, roughness: .03, metalness: .2, transparent: true, opacity: .88, clearcoat: 1 }),
    brown: new THREE.MeshPhysicalMaterial({ color: 0x3b2516, roughness: .03, metalness: .2, transparent: true, opacity: .86, clearcoat: 1 }),
    gradient: new THREE.MeshPhysicalMaterial({ color: 0x2a2e33, roughness: .03, metalness: .25, transparent: true, opacity: .8, clearcoat: 1 }),
  };
  const lm = LN[lens] || LN.clear;
  const thin = (frame === 'gold' || frame === 'silver' || frame === 'gunmetal');

  // ---------- vorm van één glas (rechter oog, centrum 0,0) ----------
  function outline(s) {
    const p = new THREE.Shape(); const N = 120;
    const pt = (t) => {
      const a = t * Math.PI * 2, c = Math.cos(a), sn = Math.sin(a);
      if (s === 'round') return [c * .52, sn * .5];
      if (s === 'square') { const e = 5; const X = Math.sign(c) * Math.pow(Math.abs(c), 2 / e), Y = Math.sign(sn) * Math.pow(Math.abs(sn), 2 / e); return [X * .6, Y * .44 + (Y < 0 ? Y * .04 : 0)]; }
      if (s === 'aviator') { let X = c * .6, Y = sn * .5; if (sn < 0) { Y = sn * .62; X = c * (.6 - .14 * Math.max(0, -c) * -sn); } if (sn > 0) Y = sn * .42; return [X - (sn < 0 ? .05 * (1 + c) * -sn : 0), Y]; }
      if (s === 'cateye') { const e = 3.6; let X = Math.sign(c) * Math.pow(Math.abs(c), 2 / e) * .6, Y = Math.sign(sn) * Math.pow(Math.abs(sn), 2 / e) * .4;
        const ox = Math.max(0, X / .6); if (Y > 0) Y += .2 * ox * ox * (Y / .4); else Y *= 1 - .25 * ox; if (Y < 0) X -= .06 * (-Y / .4) * (X > 0 ? 1 : 0); return [X, Y - .03]; }
      if (s === 'pilot') { const e = 4; const X = Math.sign(c) * Math.pow(Math.abs(c), 2 / e), Y = Math.sign(sn) * Math.pow(Math.abs(sn), 2 / e); return [X * .62, Y * .46]; }
      return [c * .5, sn * .5];
    };
    for (let i = 0; i <= N; i++) { const [X, Y] = pt(i / N); i ? p.lineTo(X, Y) : p.moveTo(X, Y); }
    return p;
  }
  const offsetShape = (shape, d) => {
    const P = shape.getPoints(160); if (P[0].distanceTo(P[P.length - 1]) < 1e-6) P.pop();
    // orientatie bepalen
    let area = 0; for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length]; area += a.x * b.y - b.x * a.y; }
    const sg = area > 0 ? 1 : -1;
    const out = P.map((p, i) => { const a = P[(i - 1 + P.length) % P.length], b = P[(i + 1) % P.length]; const t = new THREE.Vector2(b.x - a.x, b.y - a.y).normalize(); const n = new THREE.Vector2(t.y, -t.x).multiplyScalar(sg); return p.clone().add(n.multiplyScalar(d)); });
    return new THREE.Shape(out);
  };
  const scaled = (shape, k) => { const pts = shape.getPoints(120).map(v => v.clone().multiplyScalar(k)); return new THREE.Shape(pts); };

  const base = outline(shape);
  const rimW = thin ? .035 : .085;
  const depth = thin ? .04 : .09;
  const B = new THREE.Box2().setFromPoints(base.getPoints(120));
  const w = B.max.x - B.min.x, h = B.max.y - B.min.y;
  const kOut = 1 + rimW * 2 / w;
  const bridgeHalf = thin ? .11 : .17;
  const cx = w / 2 + bridgeHalf;

  // ---------- voorkant ----------
  const front = new THREE.Group(); G.add(front);
  [-1, 1].forEach(side => {
    const outer = offsetShape(base, rimW);
    outer.holes.push(new THREE.Path(base.getPoints(120)));
    const geo = new THREE.ExtrudeGeometry(outer, { depth, bevelEnabled: true, bevelThickness: thin ? .012 : .025, bevelSize: thin ? .01 : .02, bevelSegments: 4, curveSegments: 64 });
    geo.translate(0, 0, -depth / 2);
    const rim = new THREE.Mesh(geo, fm); rim.position.x = side * cx; rim.scale.x = side; front.add(rim);
    const lg = new THREE.ShapeGeometry(base, 64); const L = new THREE.Mesh(lg, lm); L.position.set(side * cx, 0, .004); L.scale.x = side; front.add(L);
    // lichte bolling via tweede lens laag
    const L2 = L.clone(); L2.position.z = -.004; front.add(L2);
    // scharnier
    const hinge = new THREE.Mesh(new THREE.BoxGeometry(.09, thin ? .07 : .12, .1), thin ? fm : FR.silver);
    hinge.position.set(side * (cx + w / 2 * kOut + .02), B.max.y * .62, -.05); front.add(hinge);
    // neuspads (metaal)
    if (thin) {
      const pad = new THREE.Mesh(new THREE.SphereGeometry(.05, 16, 12), LN.clear); pad.scale.set(.5, 1, .35); pad.position.set(side * (bridgeHalf + .07), -.12, -.1); front.add(pad);
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(.008, .008, .16, 8), fm); arm.position.set(side * (bridgeHalf + .05), -.05, -.06); arm.rotation.x = .7; front.add(arm);
    }
  });
  // brug
  if (thin) {
    const curve = new THREE.QuadraticBezierCurve3(new THREE.Vector3(-bridgeHalf - .04, B.max.y * .45, 0), new THREE.Vector3(0, B.max.y * .72, .02), new THREE.Vector3(bridgeHalf + .04, B.max.y * .45, 0));
    front.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 24, .018, 10), fm));
    if (shape === 'aviator' || shape === 'pilot') {
      const c2 = new THREE.LineCurve3(new THREE.Vector3(-cx, B.max.y * 1.06, 0), new THREE.Vector3(cx, B.max.y * 1.06, 0));
      front.add(new THREE.Mesh(new THREE.TubeGeometry(c2, 8, .016, 10), fm));
    }
  } else {
    const s = new THREE.Shape(); const y0 = B.max.y * .1, y1 = B.max.y * .62;
    s.moveTo(-bridgeHalf - .06, y1); s.quadraticCurveTo(0, y1 + .05, bridgeHalf + .06, y1); s.lineTo(bridgeHalf + .06, y0 + .1); s.quadraticCurveTo(0, y0 + .02, -bridgeHalf - .06, y0 + .1); s.closePath();
    const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelThickness: .02, bevelSize: .015, bevelSegments: 3 }); g.translate(0, 0, -depth / 2);
    front.add(new THREE.Mesh(g, fm));
  }
  // ---------- poten ----------
  const tm = temples === 'match' ? fm : (FR[temples] || fm);
  [-1, 1].forEach(side => {
    const len = 1.75;
    const s = new THREE.Shape(); const th = thin ? .022 : .045, hh = thin ? .03 : .085;
    s.moveTo(0, -hh / 2); s.lineTo(len * .78, -hh * .35); s.quadraticCurveTo(len * .92, -hh * .3, len, -.32); s.lineTo(len - .02, -.32 + hh * .5); s.quadraticCurveTo(len * .9, hh * .2, len * .78, hh * .35); s.lineTo(0, hh / 2); s.closePath();
    const g = new THREE.ExtrudeGeometry(s, { depth: th, bevelEnabled: true, bevelThickness: .008, bevelSize: .008, bevelSegments: 2, curveSegments: 24 });
    g.translate(0, 0, -th / 2);
    const t = new THREE.Mesh(g, tm);
    const pivot = new THREE.Group(); pivot.position.set(side * (cx + w / 2 * kOut + .04), B.max.y * .62, -.08);
    t.rotation.y = Math.PI / 2;
    if (side < 0) t.scale.z = -1;
    pivot.add(t); pivot.userData.side = side; G.add(pivot);
    // gouden detail op de poot
    if (!thin) { const d = new THREE.Mesh(new THREE.BoxGeometry(.012, .03, .16), FR.gold); d.position.set(side * .025, 0, -.22); pivot.add(d); }
    G.userData.temples = (G.userData.temples || []).concat(pivot);
  });
  G.userData.halfWidth = cx + w / 2 * kOut;
  // centreer
  const box = new THREE.Box3().setFromObject(front); const ctr = box.getCenter(new THREE.Vector3());
  G.children.forEach(ch => ch.position.y -= ctr.y);
  return G;
}
// open/dicht poten: 0 = dicht gevouwen, 1 = open
function setTemples(G, open) {
  (G.userData.temples || []).forEach(p => { p.rotation.y = p.userData.side * (1 - open) * (Math.PI / 2 - .08); });
}

const canvas=document.getElementById('h3dGl'),sec=document.getElementById('h3d');
if(canvas&&sec){
let renderer;try{renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'high-performance'})}catch(e){document.documentElement.classList.add('no-webgl')}
if(renderer){
const mob=()=>innerWidth<=900;
renderer.setPixelRatio(Math.min(mob()?1.5:2,devicePixelRatio||1));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
const scene=new THREE.Scene();const pm=new THREE.PMREMGenerator(renderer);scene.environment=pm.fromScene(new RoomEnvironment(renderer),.04).texture;
const cam=new THREE.PerspectiveCamera(24,1,.1,100);cam.position.set(0,.35,8.2);cam.lookAt(0,0,0);
const key=new THREE.DirectionalLight(0xfff3e0,2.2);key.position.set(3,4,5);scene.add(key);
const rim=new THREE.DirectionalLight(0xcfe0ff,2.4);rim.position.set(-4,2,-4);scene.add(rim);
const warm=new THREE.PointLight(0xd9b97f,6,9,2);warm.position.set(2.5,-1.4,2);scene.add(warm);
const STY=[{shape:'square',frame:'black',lens:'clear'},{shape:'square',frame:'black',lens:'clear'},{shape:'round',frame:'tortoise',lens:'clear'},{shape:'pilot',frame:'gold',lens:'clear'}];
const models=STY.map(o=>{const g=buildGlasses(THREE,o);g.visible=false;scene.add(g);return g});
let cur=-1;const show=i=>{if(i===cur)return;models.forEach((m,j)=>m.visible=j===i);cur=i};show(0);
const phs=[...sec.querySelectorAll('.h3d__ph')],dots=[...sec.querySelectorAll('.h3d__dots li')],cue=document.getElementById('h3dCue');
const clamp=(v,a=0,b=1)=>Math.min(b,Math.max(a,v)),ease=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
let W=0,H=0;function resize(){W=canvas.clientWidth;H=canvas.clientHeight;renderer.setSize(W,H,false);cam.aspect=W/H;cam.updateProjectionMatrix()}addEventListener('resize',resize);resize();
let sp=0,vis=true,last=performance.now();new IntersectionObserver(e=>vis=e[0].isIntersecting).observe(sec);
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
function frame(now){requestAnimationFrame(frame);const dt=Math.min(64,now-last);last=now;
 const r=sec.getBoundingClientRect(),tp=clamp(-r.top/(r.height-innerHeight));sp+=reduce?(tp-sp):(tp-sp)*(1-Math.pow(.86,dt/16.7));
 const ph=Math.min(3,Math.floor(sp*4+.0001));phs.forEach((p,i)=>p.classList.toggle('is-on',i===ph));dots.forEach((d,i)=>d.classList.toggle('is-on',i===ph));if(cue)cue.style.opacity=sp>.02?0:.6;
 if(!vis)return;
 // wissel van model rond grenzen met een snelle draai
 const seg=sp*4,local=seg-Math.floor(seg),near=Math.min(local,1-local); show(Math.min(3,Math.max(0,Math.floor(seg))));
 const m=models[cur],t=now/1000;
 const turn=near<.08?(1-near/.08):0; // 0..1 vlakbij grens
 const base=-.55+sp*Math.PI*2*1.0;
 m.rotation.set(.12+Math.sin(t*.6)*.03+(cur===1?.25:0),base+ease(turn)*Math.PI*.0+Math.sin(t*.4)*.05,Math.sin(t*.5)*.02);
 const sc=(1-.35*Math.pow(turn,1.5))*(cur===1?1.35:1);m.scale.setScalar(sc);
 setTemples(m,cur===0?clamp(.15+sp*8):cur===3?1-clamp((sp-.9)*10)*.0:1);
 m.position.y=Math.sin(t*.8)*.04;
 cam.setViewOffset(W,H,mob()?0:-W*.17,mob()?H*.16:0,W,H);cam.updateProjectionMatrix();
 renderer.render(scene,cam);
}
requestAnimationFrame(frame);
}}
