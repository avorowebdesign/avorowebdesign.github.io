(function(){
  var d=document.documentElement;d.classList.add('js');
  var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $=function(id){return document.getElementById(id)};

  // hero: kies een bandkleur, de foto in de cirkel wisselt mee en de ring draait een kwart
  var chips=$('chips'),disc=$('disc'),turn=$('turn'),cName=$('cName'),cBtn=$('cBtn'),deg=0,cache={},cur=null;
  if(chips&&disc){
    cur=chips.querySelector('input:checked');
    var first=disc.querySelector('img');
    if(cur&&first)cache[cur.value]=first;
    var img=function(inp){var k=inp.value;if(cache[k])return cache[k];var i=new Image();i.src=inp.getAttribute('data-img');i.alt='';cache[k]=i;return i};
    chips.addEventListener('change',function(e){
      var inp=e.target;if(!inp.matches||!inp.matches('input'))return;cur=inp;var k=inp.value;
      if(cName)cName.textContent=inp.getAttribute('data-name');
      if(cBtn){cBtn.textContent=inp.getAttribute('data-cta');cBtn.href=inp.getAttribute('data-link')||cBtn.href}
      var nx=img(inp),old=disc.querySelector('.is-on');
      var show=function(){if(cur.value!==k)return;if(nx.parentNode!==disc)disc.appendChild(nx);nx.classList.remove('is-on');void nx.offsetWidth;nx.classList.add('is-on');if(old&&old!==nx)old.classList.remove('is-on')};
      if(nx.complete&&nx.naturalWidth)show();else nx.onload=show;
      deg+=90;if(turn)turn.style.transform='rotate('+deg+'deg)';
    });
    var pre=function(){[].forEach.call(chips.querySelectorAll('input'),img)};
    ('requestIdleCallback' in window)?requestIdleCallback(pre):setTimeout(pre,1200);
  }

  // header + mobiel menu
  var hdr=$('hdr');
  if(hdr)addEventListener('scroll',function(){hdr.classList.toggle('is-stuck',scrollY>40)},{passive:true});
  var mb=$('menuBtn'),mn=$('mnav');
  if(mb&&mn){
    var close=function(){mb.setAttribute('aria-expanded','false');mn.classList.remove('is-open');document.body.style.overflow=''};
    mb.addEventListener('click',function(){mn.style.top=hdr.getBoundingClientRect().bottom+'px';var o=mb.getAttribute('aria-expanded')!=='true';if(!o)return close();mb.setAttribute('aria-expanded','true');mn.classList.add('is-open');document.body.style.overflow='hidden'});
    mn.addEventListener('click',function(e){if(e.target.closest('a'))close()});
    addEventListener('keydown',function(e){if(e.key==='Escape')close()});
  }

  // één laad-moment: ring tekent zich, foto en tekst komen binnen
  var go=function(){requestAnimationFrame(function(){d.classList.add('ready')})};
  var f=disc&&disc.querySelector('img');
  if(reduce||!f||(f.complete&&f.naturalWidth))go();else{f.addEventListener('load',go);f.addEventListener('error',go);setTimeout(go,1500)}
})();
