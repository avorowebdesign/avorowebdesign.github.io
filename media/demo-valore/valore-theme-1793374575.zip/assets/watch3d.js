import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
// VALORÉ – procedureel horloge naar het echte model (gegroefde bezel, Romeinse cijfers, datum + cycloop, 3-schakel band)
// buildWatch(THREE, {RBG, TextGeometry, font}, {dial:'blue'|'black'})
function buildWatch(THREE, X, o = {}) {
  const { RBG, TextGeometry, font } = X;
  const dialC = o.dial || 'blue';
  const FD = o.fontDisplay || '"Bodoni Moda", Didot, Georgia, serif';
  const FS = o.fontSans || '"Hanken Grotesk", Helvetica, Arial, sans-serif';
  const W = new THREE.Group(); W.name = 'watch';
  const TAU = Math.PI * 2;
  const cv = (w, h, draw) => { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t };

  // ---------- wijzerplaat-textuur ----------
  const blue = dialC === 'blue';
  const dialTex = cv(2048, 2048, (x, w) => {
    const c = w / 2;
    if (blue) {
      const g = x.createConicGradient(-Math.PI * .78, c, c);
      [[0, '#06205c'], [.11, '#2f63d6'], [.25, '#0c2f86'], [.5, '#051a4d'], [.61, '#2a5ccb'], [.75, '#0c2f86'], [1, '#06205c']].forEach(([s, col]) => g.addColorStop(s, col));
      x.fillStyle = g; x.fillRect(0, 0, w, w);
      for (let i = 0; i < 1440; i++) { const a = i / 1440 * TAU; x.strokeStyle = i % 2 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.05)'; x.lineWidth = 2.2; x.beginPath(); x.moveTo(c + Math.cos(a) * 30, c + Math.sin(a) * 30); x.lineTo(c + Math.cos(a) * c, c + Math.sin(a) * c); x.stroke() }
    } else {
      const g = x.createRadialGradient(c, c * .8, 50, c, c, c); g.addColorStop(0, '#1a1b1e'); g.addColorStop(1, '#0b0b0d'); x.fillStyle = g; x.fillRect(0, 0, w, w);
    }
    const v = x.createRadialGradient(c, c, c * .6, c, c, c); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,.3)'); x.fillStyle = v; x.fillRect(0, 0, w, w);
    // spoorweg-minutenring
    x.strokeStyle = 'rgba(235,240,248,.85)'; x.lineWidth = 3;
    [c * .925, c * .965].forEach(r => { x.beginPath(); x.arc(c, c, r, 0, TAU); x.stroke() });
    x.save(); x.translate(c, c); for (let i = 0; i < 60; i++) { x.save(); x.rotate(i / 60 * TAU); x.fillStyle = 'rgba(235,240,248,.85)'; x.fillRect(-2, -c * .965, 4, c * .04); x.restore() } x.restore();
    // logo
    x.textAlign = 'center'; x.fillStyle = '#eef2f8'; x.font = `500 116px ${FD}`; x.letterSpacing = '10px'; x.fillText('VALORÉ', c + 5, c - 250);
    if (!font) { // reserve: cijfers als print
      x.fillStyle = '#dfe3ea'; x.font = `600 120px ${FD}`; x.letterSpacing = '0px';
      [[0, 'XII'], [2, 'II'], [4, 'IIII'], [6, 'VI'], [8, 'VIII'], [10, 'X']].forEach(([h, t]) => { x.save(); x.translate(c, c); x.rotate(h / 12 * TAU); x.fillText(t, 0, -c * .66); x.restore() });
    }
  });
  dialTex.center.set(.5, .5); dialTex.rotation = Math.PI / 2;

  const backTex = cv(2048, 2048, (x, w) => {
    const c = w / 2; x.fillStyle = '#a9abaf'; x.fillRect(0, 0, w, w);
    for (let r = 4; r < c; r += 2) { const v = r % 6 ? 255 : 30; x.strokeStyle = `rgba(${v},${v},${v},.07)`; x.beginPath(); x.arc(c, c, r, 0, 7); x.stroke() }
    x.fillStyle = '#4b4e54'; x.textAlign = 'center'; x.font = `600 62px ${FS}`;
    const t = 'VALORÉ · LIMITED EDITION · STAINLESS STEEL · ';
    x.save(); x.translate(c, c); for (let i = 0; i < t.length; i++) { x.save(); x.rotate(i / t.length * TAU); x.fillText(t[i], 0, -c * .8); x.restore() } x.restore();
    x.font = `500 260px ${FD}`; x.fillText('V', c, c + 90);
  });
  const magTex = cv(512, 400, (x, w, h) => { x.clearRect(0, 0, w, h); const rw = w * .8, rh = h * .78, rx = (w - rw) / 2, ry = (h - rh) / 2; x.fillStyle = '#dfe3ea'; x.beginPath(); x.roundRect(rx - 14, ry - 14, rw + 28, rh + 28, 26); x.fill(); x.fillStyle = '#f8f7f3'; x.beginPath(); x.roundRect(rx, ry, rw, rh, 16); x.fill(); x.fillStyle = '#111'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = `600 230px ${FS}`; x.fillText(String(o.date || new Date().getDate()), w / 2, h / 2 + 12) });
  const dateTex = cv(256, 256, (x, w) => { x.fillStyle = '#f7f6f2'; x.fillRect(0, 0, w, w); x.fillStyle = '#111'; x.textAlign = 'center'; x.textBaseline = 'middle'; /* cijfer zit vergroot onder de loep */ });

  // ---------- materialen ----------
  const M = {
    polish: new THREE.MeshPhysicalMaterial({ color: 0xf2f1ef, metalness: 1, roughness: .045, clearcoat: .6, clearcoatRoughness: .03 }),
    brushed: new THREE.MeshPhysicalMaterial({ color: 0xdedcd9, metalness: 1, roughness: .22 }),
    flute: new THREE.MeshPhysicalMaterial({ color: 0xf4f3f1, metalness: 1, roughness: .04, flatShading: true }),
    clasp: new THREE.MeshPhysicalMaterial({ color: 0xe2e0dd, metalness: 1, roughness: .2 }),
    applied: new THREE.MeshPhysicalMaterial({ color: 0xf4f4f4, metalness: 1, roughness: .1 }),
    dial: new THREE.MeshPhysicalMaterial({ map: dialTex, metalness: blue ? .35 : .1, roughness: blue ? .3 : .45, clearcoat: 1, clearcoatRoughness: .05 }),
    back: new THREE.MeshPhysicalMaterial({ map: backTex, metalness: .9, roughness: .34 }),
    date: new THREE.MeshStandardMaterial({ map: dateTex, roughness: .5 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xffffff, metalness: 0, roughness: 0, transparent: true, opacity: .1, clearcoat: 1, clearcoatRoughness: 0, envMapIntensity: 1.8, depthWrite: false }),
    mag: new THREE.MeshBasicMaterial({ map: magTex, transparent: true, depthWrite: false }),
    cyc: new THREE.MeshPhysicalMaterial({ color: 0xdfe9ff, metalness: 0, roughness: 0, transparent: true, opacity: .32, clearcoat: 1, clearcoatRoughness: 0, envMapIntensity: 3, depthWrite: false }),
    dark: new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: .6 }),
  };
  W.userData.mats = M;
  const lathe = (pts, mat, seg = 192) => { const g = new THREE.LatheGeometry(pts.map(([r, z]) => new THREE.Vector2(r, z)), seg); g.rotateX(Math.PI / 2); return new THREE.Mesh(g, mat) };
  const disc = (r, h, m, seg = 160) => { const g = new THREE.CylinderGeometry(r, r, h, seg); g.rotateX(Math.PI / 2); return new THREE.Mesh(g, m) };
  const at = (ob, x, y, z) => { ob.position.set(x, y, z); return ob };

  // ---------- kast ----------
  const caseG = new THREE.Group(); W.add(caseG);
  caseG.add(lathe([[0, -.21], [.8, -.21], [.9, -.195], [.97, -.14], [1.0, -.06], [1.0, .04], [.98, .08], [.95, .09]], M.polish));
  // lugs: geïntegreerd, breed (zijprofiel y/z geëxtrudeerd in x)
  {
    // lug in bovenaanzicht: smal bij de band, loopt in een vloeiende boog uit naar de kast
    const s = new THREE.Shape();
    s.moveTo(.5, .6); s.lineTo(.5, 1.14); s.lineTo(.575, 1.14);
    s.bezierCurveTo(.592, 1.0, .622, .87, .69, .7); s.lineTo(.66, .6); s.closePath(); // slanke lug: van bandrand vrijwel recht naar de bezel
    const geo = new THREE.ExtrudeGeometry(s, { depth: .26, bevelEnabled: true, bevelThickness: .018, bevelSize: .016, bevelSegments: 4, curveSegments: 40, steps: 1 });
    const p = geo.attributes.position;
    const zt = y => { const u = Math.max(0, Math.min(1, (y - .8) / .34)); return .07 - Math.pow(u, 1.5) * .17 }, zb = y => -.2 + Math.max(0, (y - .8) / .34) * .03;
    for (let i = 0; i < p.count; i++) { const y = p.getY(i), t = p.getZ(i) / .26; p.setZ(i, zb(y) + (zt(y) - zb(y)) * t) }
    geo.computeVertexNormals();
    [[1, 1], [-1, 1], [1, -1], [-1, -1]].forEach(([sx, sy]) => { const m = new THREE.Mesh(geo, [M.polish, M.polish]); m.scale.set(sx, sy, 1); caseG.add(m) });
    // solide eindschakel: sluit strak aan tegen de kast, vult de ruimte tussen de lugs
    const e = new THREE.Shape();
    e.moveTo(.7, .035); e.bezierCurveTo(.9, .035, 1.01, .0, 1.1, -.05); e.quadraticCurveTo(1.14, -.075, 1.13, -.11);
    e.lineTo(1.09, -.17); e.bezierCurveTo(1.0, -.15, .9, -.17, .7, -.19); e.closePath();
    const eg = new THREE.ExtrudeGeometry(e, { depth: .99, bevelEnabled: true, bevelThickness: .018, bevelSize: .014, bevelSegments: 4, curveSegments: 32 });
    const q = eg.attributes.position; for (let i = 0; i < q.count; i++) { const a = q.getX(i), b = q.getY(i), c = q.getZ(i); q.setXYZ(i, c - .495, a, b) }
    eg.computeVertexNormals();
    [1, -1].forEach(sy => { const m = new THREE.Mesh(eg, M.brushed); m.scale.y = sy; caseG.add(m) });
  }
  // gegroefde bezel: gladde rand + facetring (elke segmentgrens is afwisselend rug/dal → vlakke facetten)
  caseG.add(lathe([[.96, .078], [1.0, .085], [1.0, .1], [.997, .108]], M.polish));
  caseG.add(lathe([[.8, .203], [.796, .216], [.778, .214], [.768, .2]], M.polish));
  {
    const N = 88, g = new THREE.LatheGeometry([new THREE.Vector2(.997, .108), new THREE.Vector2(.8, .203)], N * 2); g.rotateX(Math.PI / 2);
    const p = g.attributes.position, nx = .6, nz = .8; // normaal van het talud (naar buiten/boven)
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i), r = Math.hypot(x, y), th = Math.atan2(y, x);
      const k = Math.round(((th / TAU) * N * 2 % (N * 2) + N * 2) % (N * 2)), d = (k % 2 ? -1 : 1) * .0085;
      const rr = r + nx * d; p.setXYZ(i, x / r * rr, y / r * rr, z + nz * d);
    }
    const gn = g.toNonIndexed(); gn.computeVertexNormals(); caseG.add(new THREE.Mesh(gn, M.flute));
  }
  caseG.add(lathe([[.745, .07], [.772, .19]], M.brushed)); // rehaut
  // kroon (geribd)
  {
    const cr = new THREE.Group(); cr.position.set(1.03, 0, -.04); caseG.add(cr);
    const c = new THREE.Mesh(new THREE.CylinderGeometry(.12, .12, .14, 48), M.polish); c.rotation.z = Math.PI / 2; c.position.x = .07; cr.add(c);
    const n = new THREE.InstancedMesh(new THREE.BoxGeometry(.12, .02, .016), M.polish, 24), d = new THREE.Object3D();
    for (let i = 0; i < 24; i++) { const a = i / 24 * TAU; d.position.set(.07, Math.cos(a) * .121, Math.sin(a) * .121); d.rotation.set(a, 0, 0); d.updateMatrix(); n.setMatrixAt(i, d.matrix) } cr.add(n);
    const tube = new THREE.Mesh(new THREE.CylinderGeometry(.06, .06, .06, 32), M.polish); tube.rotation.z = Math.PI / 2; cr.add(tube);
  }
  // kastbodem
  { const b = new THREE.Mesh(new THREE.CircleGeometry(.78, 160), M.back); b.rotation.y = Math.PI; b.position.z = -.211; W.add(b) }

  // ---------- wijzerplaat ----------
  const dialG = new THREE.Group(); W.add(dialG);
  { const d = disc(.84, .02, [M.dark, M.dial, M.dark]); d.position.z = .065; dialG.add(d) }
  const Z = .076, Rn = .6;
  const baton = new RBG(.032, .15, .02, 2, .008);
  for (let h = 1; h < 12; h += 2) { if (h === 3) continue; const a = Math.PI / 2 - h / 12 * TAU; const m = new THREE.Mesh(baton, M.applied); m.position.set(Math.cos(a) * .64, Math.sin(a) * .64, Z + .01); m.rotation.z = a - Math.PI / 2; dialG.add(m) }
  if (font) {
    [[0, 'XII'], [2, 'II'], [4, 'IIII'], [6, 'VI'], [8, 'VIII'], [10, 'X']].forEach(([h, t]) => {
      const g = new TextGeometry(t, { font, size: .125, height: .012, curveSegments: 5, bevelEnabled: true, bevelThickness: .002, bevelSize: .0012, bevelSegments: 1 });
      g.computeBoundingBox(); const b = g.boundingBox; g.translate(-(b.max.x + b.min.x) / 2, -(b.max.y + b.min.y) / 2, 0);
      const m = new THREE.Mesh(g, M.applied); const a = Math.PI / 2 - h / 12 * TAU;
      m.position.set(Math.cos(a) * Rn, Math.sin(a) * Rn, Z); m.rotation.z = a - Math.PI / 2; dialG.add(m);
    });
  }
  // datumvenster op 3 uur
  {
    const dx = .6, f = new THREE.Shape(); const w = .2, h = .16; f.moveTo(-w / 2 - .018, -h / 2 - .018); f.lineTo(w / 2 + .018, -h / 2 - .018); f.lineTo(w / 2 + .018, h / 2 + .018); f.lineTo(-w / 2 - .018, h / 2 + .018); f.closePath();
    const hole = new THREE.Path(); hole.moveTo(-w / 2, -h / 2); hole.lineTo(-w / 2, h / 2); hole.lineTo(w / 2, h / 2); hole.lineTo(w / 2, -h / 2); hole.closePath(); f.holes.push(hole);
    dialG.add(at(new THREE.Mesh(new THREE.ExtrudeGeometry(f, { depth: .012, bevelEnabled: false }), M.applied), dx, 0, Z));
    const dd = new THREE.Mesh(new THREE.PlaneGeometry(w, h), M.date); dd.position.set(dx, 0, Z + .002); dialG.add(dd);
  }

  // ---------- wijzers ----------
  const handsG = new THREE.Group(); W.add(handsG);
  const stick = (L, Wd) => {
    const g = new THREE.Group(), s = new THREE.Shape();
    s.moveTo(-Wd / 2, -.08); s.lineTo(Wd / 2, -.08); s.lineTo(Wd / 2, L - Wd * 1.6); s.lineTo(0, L); s.lineTo(-Wd / 2, L - Wd * 1.6); s.closePath();
    const m = new THREE.Mesh(new THREE.ExtrudeGeometry(s, { depth: .008, bevelEnabled: true, bevelThickness: .004, bevelSize: .004, bevelSegments: 2 }), M.polish); g.add(m); return g
  };
  const hH = stick(.42, .045), hM = stick(.66, .036), hS = new THREE.Group();
  hH.position.z = .1; hM.position.z = .118;
  hS.add(at(new THREE.Mesh(new THREE.BoxGeometry(.01, .9, .005), M.polish), 0, .27, 0)); hS.add(at(disc(.026, .006, M.polish, 32), 0, -.13, 0)); hS.position.z = .136;
  handsG.add(hH, hM, hS); handsG.add(at(disc(.03, .05, M.polish, 40), 0, 0, .13));
  W.userData.hands = { h: hH, m: hM, s: hS };

  // ---------- glas + cycloop ----------
  { const R = 3.6, g = new THREE.SphereGeometry(R, 96, 24, 0, TAU, 0, Math.asin(.79 / R)); g.rotateX(Math.PI / 2); g.translate(0, 0, .225 - Math.sqrt(R * R - .79 * .79)); const m = new THREE.Mesh(g, M.glass); m.renderOrder = 5; W.add(m); W.userData.glass = m }
  { const c = new THREE.Mesh(new RBG(.31, .25, .09, 6, .045), M.cyc); c.position.set(.6, 0, .25); c.renderOrder = 6; W.add(c); W.userData.cyc = c;
    const mg = new THREE.Mesh(new THREE.PlaneGeometry(.27, .21), M.mag); mg.position.z = -.005; mg.renderOrder = 5; c.add(mg) }

  // ---------- band (3 ronde schakels per rij, middelste gepolijst) ----------
  const bandG = new THREE.Group(); W.add(bandG);
  const A = 1.6, B = 1.3, y0 = 1.11, z0 = -.12, th0 = Math.asin(y0 / A), ZC = z0 - B * Math.cos(th0);
  const tbl = []; { let L = 0, py = A * Math.sin(th0), pz = ZC + B * Math.cos(th0); tbl.push([0, th0]); for (let i = 1; i <= 600; i++) { const t = th0 + (Math.PI - th0) * i / 600, y = A * Math.sin(t), z = ZC + B * Math.cos(t); L += Math.hypot(y - py, z - pz); tbl.push([L, t]); py = y; pz = z } }
  const bandLen = tbl[tbl.length - 1][0];
  const arc = (s, sy) => { s = Math.min(s, bandLen); let i = 1; while (i < tbl.length - 1 && tbl[i][0] < s) i++; const [l0, t0] = tbl[i - 1], [l1, t1] = tbl[i]; const t = t0 + (t1 - t0) * ((s - l0) / ((l1 - l0) || 1)); return { y: sy * A * Math.sin(t), z: ZC + B * Math.cos(t), rx: sy * Math.atan2(-B * Math.sin(t), A * Math.cos(t)) } };
  {
    const CL = .7, step = .23, N = Math.ceil((bandLen - CL) / step);
    const gC = new RBG(.24, .224, .13, 6, .062), gS = new RBG(.37, .224, .1, 5, .05);
    const mC = new THREE.InstancedMesh(gC, M.polish, N * 2), mS = new THREE.InstancedMesh(gS, M.brushed, N * 4), d = new THREE.Object3D(); let ic = 0, is = 0;
    [1, -1].forEach(sy => { for (let i = 0; i < N; i++) { const a = arc((i + .5) * step, sy); d.position.set(0, a.y, a.z); d.rotation.set(a.rx, 0, 0); d.translateZ(.012); d.updateMatrix(); mC.setMatrixAt(ic++, d.matrix); d.translateZ(-.012); [-1, 1].forEach(sx => { d.position.set(sx * .31, a.y, a.z); d.updateMatrix(); mS.setMatrixAt(is++, d.matrix) }) } });
    mC.count = ic; mS.count = is; bandG.add(mC, mS);
    // vouwsluiting onderaan: één gladde, gepolijste plaat die de pols volgt, met scharnierpennen aan de uiteinden
    const cg = new THREE.BoxGeometry(.94, CL, .085, 1, 48, 1), cp = cg.attributes.position;
    for (let i = 0; i < cp.count; i++) { const x = cp.getX(i), yl = cp.getY(i) + CL / 2, zl = cp.getZ(i) - .008, a = arc(bandLen - CL + yl, 1); cp.setXYZ(i, x, a.y - zl * Math.sin(a.rx), a.z + zl * Math.cos(a.rx)) }
    cg.computeVertexNormals();
    [1, -1].forEach(sy => { const m = new THREE.Mesh(cg, M.clasp); m.scale.y = sy; bandG.add(m) });
    // drukknopjes aan de zijkant van de sluiting
    [1, -1].forEach(sy => { const a = arc(bandLen - .3, sy), t = new THREE.Mesh(new RBG(.05, .1, .06, 2, .02), M.polish); t.position.set(sy * .48, a.y, a.z); t.rotation.x = a.rx; bandG.add(t) });
  }

  const KD = .9; dialG.scale.set(KD, KD, 1); handsG.scale.set(KD, KD, 1); W.userData.cyc.position.x = .6 * KD; W.userData.cyc.scale.set(KD, KD, 1);
  W.userData.wrist = { A, B, ZC };
  W.userData.parts = { caseG, dialG, handsG, bandG };
  setTime(W, new Date());
  return W;
}

function setTime(W, d, tz = 'Europe/Amsterdam') {
  let h = d.getHours(), m = d.getMinutes(), s = d.getSeconds() + d.getMilliseconds() / 1000;
  try { const f = new Intl.DateTimeFormat('nl-NL', { timeZone: tz, hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: false }).formatToParts(d); const g = t => +f.find(p => p.type === t).value; h = g('hour'); m = g('minute'); s = g('second') + d.getMilliseconds() / 1000 } catch (e) { }
  const H = W.userData.hands, T = Math.PI * 2;
  H.s.rotation.z = -s / 60 * T; H.m.rotation.z = -(m + s / 60) / 60 * T; H.h.rotation.z = -((h % 12) + m / 60) / 12 * T;
}

// fotostudio-omgeving: donkere ruimte met softboxen → harde, heldere reflecties in staal
function studioEnv(THREE, r, warm = false) {
  const sc = new THREE.Scene();
  const room = new THREE.Mesh(new THREE.BoxGeometry(30, 30, 30), new THREE.MeshBasicMaterial({ color: 0x9a9a9e, side: THREE.BackSide })); sc.add(room);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.MeshBasicMaterial({ color: 0x2a2a2c })); floor.rotation.x = -Math.PI / 2; floor.position.y = -5; sc.add(floor);
  const card = new THREE.Mesh(new THREE.PlaneGeometry(3, 12), new THREE.MeshBasicMaterial({ color: 0x18181a, side: THREE.DoubleSide })); card.position.set(4, 0, 6); card.lookAt(0, 0, 0); sc.add(card);
  const box = (w, h, x, y, z, k, tint) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(tint || 0xffffff).multiplyScalar(k), side: THREE.DoubleSide })); m.position.set(x, y, z); m.lookAt(0, 0, 0); sc.add(m) };
  box(10, 6, 0, 9, 2, 2.2);                    // grote softbox boven
  box(1.4, 9, -7, 1, 3, 5);                    // striplight links
  box(1.4, 9, 7, 1, -2, 4.2);                  // striplight rechts
  box(8, 2, 0, -2, 8, .9, warm ? 0xffd9a8 : 0xffffff); // zachte opheldering voor
  box(6, 3, -3, 3, -8, 2.4, warm ? 0xffc98a : 0xdfe8ff); // randlicht achter
  const pm = new THREE.PMREMGenerator(r); const t = pm.fromScene(sc, .02).texture; pm.dispose(); return t;
}

/* ===== VALORÉ 3D: hero (scroll) + productviewer (slepen) ===== */
const TAU3 = Math.PI * 2;
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v)), lerp = (a, b, t) => a + (b - a) * t, ease = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
let _assets;
async function assets() {
  if (_assets) return _assets;
  _assets = (async () => {
    try { await Promise.all([document.fonts.load('500 40px "Bodoni Moda"'), document.fonts.load('600 40px "Hanken Grotesk"'), document.fonts.load('500 40px "Hanken Grotesk"')]) } catch (e) { }
    let font = null; try { font = await new FontLoader().loadAsync('https://cdn.jsdelivr.net/npm/three@0.160.0/examples/fonts/droid/droid_serif_regular.typeface.json') } catch (e) { }
    return { RBG: RoundedBoxGeometry, TextGeometry, font };
  })();
  return _assets;
}
function makeRenderer(canvas, exposure = 1) {
  let r; try { r = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' }) } catch (e) { return null }
  r.setPixelRatio(Math.min(innerWidth < 820 ? 1.5 : 2, devicePixelRatio || 1)); r.outputColorSpace = THREE.SRGBColorSpace; r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = exposure; return r;
}
function studio(r, warm) {
  const s = new THREE.Scene(); s.environment = studioEnv(THREE, r, warm);
  const key = new THREE.DirectionalLight(warm ? 0xffe8cc : 0xffffff, warm ? 2.6 : 2.2); key.position.set(3, 5, 6); s.add(key);
  const rim = new THREE.DirectionalLight(0xcfdcff, 1.6); rim.position.set(-5, 2, -3); s.add(rim);
  const low = new THREE.DirectionalLight(warm ? 0xc9a46a : 0xffffff, warm ? 1.1 : .5); low.position.set(2, -4, 3); s.add(low);
  return s;
}

/* ---------- hero ---------- */
async function hero() {
  const canvas = document.getElementById('h3dGl'), sec = document.getElementById('h3d'); if (!canvas || !sec) return;
  const r = makeRenderer(canvas, 1.05); if (!r) { document.documentElement.classList.add('no-webgl'); return }
  const A = await assets(); const scene = studio(r, true);
  const cam = new THREE.PerspectiveCamera(22, 1, .1, 100); cam.position.set(0, 0, 10); cam.lookAt(0, 0, 0);
  const rig = new THREE.Group(); scene.add(rig);
  const blue = buildWatch(THREE, A, { dial: 'blue' }), black = buildWatch(THREE, A, { dial: 'black' }); black.visible = false; rig.add(blue, black);
  sec.classList.add('is-3d');
  const phs = [...sec.querySelectorAll('.h3d__ph')], dots = [...sec.querySelectorAll('.h3d__prog li')], cue = document.getElementById('h3dCue'), tEl = document.getElementById('h3dTime');
  // p, rx, ry, rz, schaal, x, y
  const K = [
    [0, -.16, -.62, .06, 1, 0, 0],
    [.2, -.12, -.3, .03, 1, 0, 0],
    [.3, -.42, -.2, .18, 2.2, .7, -1.15],
    [.44, -.38, -.34, .24, 2.2, .7, -1.15],
    [.5, -.12, -.3, .04, 1.05, 0, 0],
    [.565, -.12, -.3 + TAU3, .04, 1.05, 0, 0],
    [.72, -.1, -.5 + TAU3, .04, 1, 0, 0],
    [.84, -.34, -1.0 + TAU3, .06, .95, 0, 0],
    [1, -.3, -.75 + TAU3, .05, .95, 0, 0],
  ];
  const at = p => { let i = 0; while (i < K.length - 2 && p >= K[i + 1][0]) i++; const a = K[i], b = K[i + 1], t = ease(clamp((p - a[0]) / (b[0] - a[0]))); return a.map((v, j) => lerp(v, b[j], t)) };
  let W = 0, H = 0, mob = false;
  const resize = () => { W = canvas.clientWidth; H = canvas.clientHeight; mob = W < 820; r.setSize(W, H, false); cam.aspect = W / H; cam.updateProjectionMatrix() };
  addEventListener('resize', resize); resize();
  let sp = 0, vis = true, last = performance.now(), lastSec = -1; new IntersectionObserver(e => vis = e[0].isIntersecting).observe(sec);
  function frame(now) {
    requestAnimationFrame(frame); const dt = Math.min(64, now - last); last = now;
    const b = sec.getBoundingClientRect(), tp = clamp(-b.top / (b.height - innerHeight));
    sp += reduce ? (tp - sp) : (tp - sp) * (1 - Math.pow(.88, dt / 16.7));
    const ph = Math.min(3, Math.floor(sp * 4 + .02)); phs.forEach((p, i) => p.classList.toggle('is-on', i === ph)); dots.forEach((d, i) => d.classList.toggle('is-on', i <= ph));
    if (cue) cue.style.opacity = sp > .02 ? 0 : .7;
    const d = new Date(); if (d.getSeconds() !== lastSec) { lastSec = d.getSeconds(); if (tEl) tEl.textContent = d.toLocaleTimeString('nl-NL', { timeZone: 'Europe/Amsterdam', hour: '2-digit', minute: '2-digit' }) }
    if (!vis) return;
    const k = at(sp), t = now / 1000, sw = reduce ? 0 : 1;
    const useBlack = sp > .532; blue.visible = !useBlack; black.visible = useBlack;
    setTime(useBlack ? black : blue, d);
    rig.rotation.set(k[1] + Math.sin(t * .5) * .025 * sw, k[2] + Math.sin(t * .35) * .04 * sw, k[3]);
    const base = mob ? .72 : 1; rig.scale.setScalar(k[4] * base);
    // horloge rechts op desktop, boven op mobiel
    const X = mob ? 0 : 1.15, Y = mob ? 1.05 : 0;
    rig.position.set(X + k[5] * base, Y + k[6] * base + Math.sin(t * .8) * .03 * sw, 0);
    r.render(scene, cam);
  }
  requestAnimationFrame(frame);
}

/* ---------- productviewer ---------- */
async function viewer() {
  const box = document.getElementById('pdp3d'), canvas = document.getElementById('pdpGl'); if (!box || !canvas) return;
  const r = makeRenderer(canvas, 1); if (!r) return;
  const A = await assets(); const scene = studio(r, false);
  const cam = new THREE.PerspectiveCamera(22, 1, .1, 100); cam.position.set(0, .4, 10); cam.lookAt(0, 0, 0);
  const w = buildWatch(THREE, A, { dial: box.dataset.dial || 'blue' }); const rig = new THREE.Group(); rig.add(w); scene.add(rig);
  box.classList.add('is-3d');
  const size = () => { const s = box.clientWidth; r.setSize(s, s, false); cam.aspect = 1; cam.updateProjectionMatrix() }; addEventListener('resize', size); size();
  let ry = -.5, rx = -.1, vy = 0, drag = false, px = 0, py = 0, idle = 0, vis = true, last = performance.now();
  new IntersectionObserver(e => vis = e[0].isIntersecting).observe(box);
  canvas.addEventListener('pointerdown', e => { drag = true; px = e.clientX; py = e.clientY; canvas.setPointerCapture(e.pointerId); box.classList.add('is-drag') });
  canvas.addEventListener('pointermove', e => { if (!drag) return; const dx = e.clientX - px, dy = e.clientY - py; px = e.clientX; py = e.clientY; vy = dx * .01; ry += vy; rx = clamp(rx + dy * .006, -.9, .6); idle = performance.now() });
  const up = () => { drag = false; box.classList.remove('is-drag'); idle = performance.now() }; canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
  function frame(now) {
    requestAnimationFrame(frame); const dt = Math.min(64, now - last) / 16.7; last = now; if (!vis) return;
    if (!drag) { ry += vy; vy *= Math.pow(.93, dt); if (!reduce && now - idle > 2500) ry += .004 * dt }
    setTime(w, new Date()); rig.rotation.set(rx, ry, 0); w.scale.setScalar(.92); r.render(scene, cam);
  }
  requestAnimationFrame(frame);
}
hero(); viewer();
