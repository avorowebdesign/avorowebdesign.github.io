/* dar · vloeibaar licht: langzaam stromende parfumolie in wijnrood en goud (WebGL, één shader) */
(function () {
  const cv = document.getElementById('heroGl'), sec = document.getElementById('hero'); if (!cv || !sec) return;
  const gl = cv.getContext('webgl', { antialias: false, premultipliedAlpha: false }); if (!gl) { sec.classList.add('no-gl'); return }
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const vs = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';
  const fs = `precision highp float;uniform vec2 uR;uniform float uT;uniform vec2 uM;uniform float uMI;
  float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
  float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y);}
  float fbm(vec2 p){float v=0.,a=.5;mat2 m=mat2(1.6,1.2,-1.2,1.6);for(int i=0;i<5;i++){v+=a*n(p);p=m*p;a*=.5;}return v;}
  void main(){
    vec2 uv=gl_FragCoord.xy/uR;vec2 p=(gl_FragCoord.xy-.5*uR)/uR.y;float t=uT*.035;
    vec2 m=(uM-.5*uR)/uR.y;float md=length(p-m);
    p+= (p-m)*.08*exp(-md*3.)*uMI;                     /* olie wijkt zacht voor de cursor */
    vec2 q=vec2(fbm(p*1.3+vec2(0.,t)),fbm(p*1.3+vec2(5.2,1.3)-t));
    vec2 r=vec2(fbm(p*1.5+2.8*q+vec2(1.7,9.2)+t*.7),fbm(p*1.5+2.8*q+vec2(8.3,2.8)-t*.6));
    float f=fbm(p*1.1+2.4*r);
    vec3 wine=vec3(.141,.031,.055), mid=vec3(.227,.059,.094), bord=vec3(.36,.1,.15), amber=vec3(.55,.29,.13), gold=vec3(.79,.63,.29);
    vec3 c=mix(wine,mid,smoothstep(.2,.55,f));
    c=mix(c,bord,smoothstep(.45,.75,f)*.8);
    c=mix(c,amber,smoothstep(.62,.92,f+length(q)*.15)*.75);
    float line=pow(1.-abs(fract(f*5.5+r.x*.6)-.5)*2.,28.);   /* dunne lichtlijnen zoals licht door olie */
    c+=gold*line*.22*smoothstep(.35,.8,f);
    c+=gold*.16*exp(-md*2.6)*uMI;                          /* warm licht bij de cursor */
    c*=mix(.55,1.,smoothstep(1.25,.25,length((uv-vec2(.62,.5))*vec2(1.5,1.))));  /* vignet */
    c+=(h(gl_FragCoord.xy+uT)-.5)*.018;                    /* filmkorrel */
    gl_FragColor=vec4(c,1.);
  }`;
  const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); return o };
  const pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(pr);
  if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) { sec.classList.add('no-gl'); return }
  gl.useProgram(pr); const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const pl = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(pl); gl.vertexAttribPointer(pl, 2, gl.FLOAT, false, 0, 0);
  const uR = gl.getUniformLocation(pr, 'uR'), uT = gl.getUniformLocation(pr, 'uT'), uM = gl.getUniformLocation(pr, 'uM'), uMI = gl.getUniformLocation(pr, 'uMI');
  const S = Math.min(1, (devicePixelRatio || 1) * .6); let W = 0, H = 0;
  const size = () => { W = Math.round(cv.clientWidth * S); H = Math.round(cv.clientHeight * S); cv.width = W; cv.height = H; gl.viewport(0, 0, W, H) };
  addEventListener('resize', size); size();
  let mx = W * .7, my = H * .5, tx = mx, ty = my, mi = 0, ti = 0;
  sec.addEventListener('pointermove', e => { const r = cv.getBoundingClientRect(); tx = (e.clientX - r.left) * S; ty = (r.bottom - e.clientY) * S; ti = 1 });
  sec.addEventListener('pointerleave', () => ti = 0);
  let vis = true; new IntersectionObserver(e => vis = e[0].isIntersecting).observe(sec);
  const t0 = performance.now();
  function draw(now) {
    mx += (tx - mx) * .05; my += (ty - my) * .05; mi += (ti - mi) * .04;
    gl.uniform2f(uR, W, H); gl.uniform1f(uT, reduce ? 40 : (now - t0) / 1000 + 40); gl.uniform2f(uM, mx, my); gl.uniform1f(uMI, mi);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  if (reduce) { draw(performance.now()); addEventListener('resize', () => draw(performance.now())); return }
  (function loop(now) { requestAnimationFrame(loop); if (vis) draw(now) })(performance.now());
  sec.classList.add('is-gl');
})();
